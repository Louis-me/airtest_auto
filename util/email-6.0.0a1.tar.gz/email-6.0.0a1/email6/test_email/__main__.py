from email6.test_email import test_main

test_main()
